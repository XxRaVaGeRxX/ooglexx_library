#ifndef OOGLEXXTEXTTOOL_H
#define OOGLEXXTEXTTOOL_H

void s_Type(const char* text);

void b_Type(const char* text);

void q_Type(const char* text);

void e_Type(const char* text);

void c_Type(const char* text);

void g_Type(const char* text);

void no_newL(const char* text);

void falseloadF();

void falseLoad();

void writeFile(const std::string& filename, const std::string& content);

#endif // OOGLEXXTEXTTOOL_H

